sap.ui.define([
	"krgoiitpgr5clb05/zui_rt_snd/test/unit/controller/App.controller"
], function () {
	"use strict";
});
