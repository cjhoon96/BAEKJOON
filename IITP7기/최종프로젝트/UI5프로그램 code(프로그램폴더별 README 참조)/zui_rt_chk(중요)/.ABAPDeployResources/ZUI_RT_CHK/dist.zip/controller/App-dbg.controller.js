sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/core/Fragment'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, Fragment) {
        "use strict";

        return Controller.extend("kr.go.iitp.gr5.clb05.zuirtchk.controller.App", {
            onInit: function () {
            }
        });
    });
