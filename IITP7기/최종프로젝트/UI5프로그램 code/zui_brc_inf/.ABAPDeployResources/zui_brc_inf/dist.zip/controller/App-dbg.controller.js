sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("kr.go.iitp.gr5.clb05.zuibrcinf.controller.App", {
            onInit: function () {
                this._oView = this.getView(); 
                this._oSTOProcModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZGWB05_STO_PROCESS_SRV");
            },

            // onRangeChange: function (oEvent) {
            //     var oVizFrame = this.getView().byId("idVizFrame");
            //     // oVizFrame.setModel(this._oSTOProcModel);
            //     console.log(oEvent.getParameter("from"));
            //     oVizFrame.getDataset().getBinding("data").filter([ 
            //         new sap.ui.model.Filter({
            //             path: "Execdate", 
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: oEvent.getParameter("from"),
            //             value2: oEvent.getParameter("to")
            //         })
            //     ]);
            //     console.log(oVizFrame.getDataset().getBinding("data"));
            //     oVizFrame.getDataset().getBinding("data").refresh();
            // },

            onDataSelect: function (oEvent) {
                var clickedData = oEvent.getParameter("data")[0].data
                sap.m.MessageToast.show("Total " + clickedData.Salestotal + " KRW");
            }
        });
    });
