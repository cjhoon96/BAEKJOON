/* global QUnit */

sap.ui.require(["kr/go/iitp/gr5/clb05/zuirtchk/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
