sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/viz/ui5/data/FlattenedDataset",
    "sap/viz/ui5/controls/common/feeds/FeedItem"
], 
    function (Controller, FlattenedDataset, FeedItem) {
        "use strict";
        return Controller.extend("kr.go.iitp.gr5.clb05.zuibrcstk.controller.Detail", {
            onInit: function () {
                //Controller에 Hook되어 있는 init Event(최초 초기화시)
                
                //Detail View가 보였다는 것은 화면이 최소 Master-Detail(View)가 동시에 화면에 보인다는 것이다.
                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                // this.oRouter = UIComponent.getRouterFor(this); // 과 동일?????           확인 필요
                
                
                this.oModel = this.oOwnerComponent.getModel();
                //Component에 붙어있는 layout이라는 속성을 가지고 있는 JSONModel
                
                this._selectedRow = "";

                console.log("yys","Detail","onInit",this.oModel);

                this.oRouter.getRoute("master").attachPatternMatched(this._onProductMatched, this);
                this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);
                this.oRouter.getRoute("detailDetail").attachPatternMatched(this._onProductMatched, this);
            },

            onCreateSTOApv: function () {
                var oTable = this.byId("tblotherbrc")
                var selectedIdx = oTable.getSelectedIndices()[0];
                if (!isNaN(selectedIdx)) {
                    var oRowContext = oTable.getContextByIndex(selectedIdx); 
                    var sPath = oRowContext.sPath;
                    var apvData = sPath.split("/").slice(-1).pop(); 
                    var oNextUIState;
                    //String을 /으로 split한 Array에서 뒷에서 1개를(-1) 읽어들인다음 pop() 을통해 반환된 index 숫자 를 value를 product에 넣는다.
                    console.log(this.oOwnerComponent);
                    this.oOwnerComponent.getHelper().then(function (oHelper) {
                        oNextUIState = oHelper.getNextUIState(2);
                        console.log(oHelper);
                        this.oRouter.navTo("detailDetail", {
                            layout: oNextUIState.layout,
                            apvData: apvData,
                            product: this._product
                        });
                    }.bind(this));
                    
                    // 패턴의 변수를 지정해 준다.
                } else {
                    sap.m.MessageBox.error("요청 지점을 선택하세요.");
                }
            },

            _onProductMatched: function (oEvent) {
                //Detail은 Item 1개에만 Binding하므로 Context(Element) Binding으로 지정해 준다.
                this._product = oEvent.getParameter("arguments").product || this._product || "0";
                console.log(oEvent.getParameter("arguments"));
                console.log(this._product);
                // 패턴의 product 변수를 가져다 쓴다
                // oEvent.getParameter("arguments").product 와 this._product 에 문자열이 없는 경우 앞의 것을 우선으로 하여 this._product 에 부여

                this.getView().bindElement({
                    path: "/" + this._product,
                    model: "stockData"
                });
                var oBinding = this.byId("tblotherbrc").getBinding("rows");
                console.log(this.getView().getModel("stockData").getProperty("/" + this._product))
                oBinding.filter([ new sap.ui.model.Filter("prodid", "EQ", this.getView().getModel("stockData").getProperty("/" + this._product).prodid)]);

                var oVizFrame = this.getView().byId("idVizFrame");
                oVizFrame.setModel(this.oOwnerComponent.getModel("stoProc"));
                oVizFrame.getDataset().getBinding("data").filter([ 
                    new sap.ui.model.Filter("Prodid", "EQ", this.getView().getModel("stockData").getProperty("/" + this._product).prodid),
                    new sap.ui.model.Filter("Giplant", "EQ", this.getView().getModel("stockData").getProperty("/" + this._product).plantid),
                ]);
                console.log(oVizFrame.getDataset().getBinding("data"));
            },

            handleFullScreen: function () {
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
                this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
            },
    
            handleExitFullScreen: function () {
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
                this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
            },
    
            handleClose: function () {
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
                this.oRouter.navTo("master", {layout: sNextLayout});
            },	

            onExit: function () {
                //Controller에 Hook되어 있는 Exit Event(controller가 제거될대)
                
                console.log("yys","Detail","onExit");
                this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
                this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
            }
            
        });
    });