sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    "sap/f/library",
    "sap/ui/core/UIComponent"
],
	function ( Controller, Filter, FilterOperator, Sorter, fioriLibrary, UIComponent) {
		"use strict";
		return Controller.extend("kr.go.iitp.gr5.clb05.zuibrcstk.controller.Master", {
			onInit: function () {
				this.oView = this.getView();
            
                this._SortBy = "prodid"
                // 정렬 기준을 값으로 넣어놓을 키
                this._Descending = false;
                // 오름차순인지 내림차순인지 정보를 넣어놓을 키
                this.oProductsTable = this.oView.byId("productsTable");
                console.log(this.oProductsTable, '확인')
                var oBinding = this.oProductsTable.getBinding("items",'stockData');
                console.log(oBinding);
                console.log('오류 check');
                // var oSorter = [new Sorter(this._SortBy, this._Descending), new Sorter('preStock', this._Descending)];
                // oBinding.sort(oSorter);
                //onInit에서 Sorter 를 설정하여 기본 값은 상품 코드 기준 오름 차순으로 설정하여준다.

				//Router를 등록해 준다
				this.oRouter = this.getOwnerComponent().getRouter();
                // this.oRouter = UIComponent.getRouterFor(this); // 과 동일?????           확인 필요
			},


            // SearchField 에 검색하는 경우 사용
			onSearch: function (oEvent) {
                var oTableSearchState = [],
                    sQuery = oEvent.getParameter("query");  //검색어의 문자열을 받아온다.
    
                if (sQuery) {                               //검색어가 있는 경우
                    oTableSearchState = new Filter({
                            filters: [
                                new Filter("prodid", FilterOperator.Contains, sQuery),           //id 에 검색어가 포함된 경우
                                new Filter("prodnm", FilterOperator.Contains, sQuery),         //이름에 에 검색어가 포함된 경우
                            ],              
                            and: false,                                                         //해당 조건의 filter 두개를 or 로 묶어 새로운 filter 구성
                        }
                    ); //Name에 검색어가 포함된
                }
    
                this.oProductsTable.getBinding("items").filter(oTableSearchState, "Application"); //왜 array 형태로 filter를 구성 하였을까?
			},


            //Product 아이콘 토글 버튼을 누를시 실행
            onSortBy: function (oEvent) {
                var checkPressed = oEvent.getSource().getPressed();
                var oBinding = this.oProductsTable.getBinding("items")
                console.log(oBinding);
                
                if (checkPressed){
                    this._SortBy = "stock"                              // 정렬 기준의 값을 바꿔준 후
                } else {
                    this._SortBy = "prodid"
                }
                
                var oSorter = [new Sorter(this._SortBy, this._Descending), new Sorter('prestock', this._Descending)];       //Sorter 를 새로 설정해 준다. 
                oBinding.sort(oSorter);
            },


            // sort 아이콘 버튼을 누를시 실행
            onSortMode: function () {
                this._Descending = !this._Descending;
                var oBinding = this.oProductsTable.getBinding("items");
                var oSorter = [new Sorter(this._SortBy, this._Descending), new Sorter('prestock', this._Descending)];
    
                oBinding.sort(oSorter);
            },


			onListItemPress: function (oEvent) {
				//기존 : Master의 ListItem을 클릭하면 flexible column layout의 속성layout을 변경하여 화면에 표시해 주었다.
				//var oFCL = this.oView.getParent().getParent();
				//oFCL.setLayout( fioriLibrary.LayoutType.TwoColumnsMidExpanded);

				//변경 : Master의 ListItem을 클릭하면 Item의 Product를 확인하여 Router를 호출해 준다.
				//productPath = "/Stock/(눌린 라인이 몇번째 index의 상품인지)" 이렇게 들어온다.
				var productPath = oEvent.getSource().getBindingContext("stockData").getPath();
                var product = productPath.split("/").slice(-1).pop(); 
				var oNextUIState;
                this.getOwnerComponent().getHelper().then(function (oHelper) {
                    oNextUIState = oHelper.getNextUIState(1);
                    console.log(oHelper);
                    this.oRouter.navTo("detail", {
                        layout: oNextUIState.layout,
                        product: product
                    });
                }.bind(this));
			},
		});
	}
);
