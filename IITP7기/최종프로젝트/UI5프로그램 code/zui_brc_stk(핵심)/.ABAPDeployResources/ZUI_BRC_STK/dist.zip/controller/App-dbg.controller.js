sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("kr.go.iitp.gr5.clb05.zuibrcstk.controller.App", {
            onInit: function () {
                
                this.oOwnerComponent = this.getOwnerComponent();  //App의 public property(oOwnerComponent)세팅
                //현 controller 와 연결된 view 와 연결된 component instance 를 불러온다.
                this.oRouter = this.oOwnerComponent.getRouter();  //App의 public property(oRouter)세팅
                // router instance 를 불러온다.
                // this.oRouter = sap.ui.core.UIComponent.getRouterFor(this); //?????
                this.oRouter.attachRouteMatched(this._onRouteMatched, this); //Router에 RouterMatched(event handler)세팅
                // fnfunction _onRouteMatched 를 이 oListener sap.ui.core.routing.Router oRouter 의 routeMatched 이벤트에 연결한다. 
                // this가 기본값? 확인 필요
                // 사용자의 정상적인 URL을 입력하면 호출. 사용자의 URL접속 통계를 획득함. 없어도 되나? 확인
                // 후자의 this는 oRouter???                                                                                             질문
            },
    
            _onRouteMatched: function (oEvent) {
                //Router의 URL pattern이 일치하면 자동으로 계속 호출된다.
                var sRouteName = oEvent.getParameter("name");
                var oArguments = oEvent.getParameter("arguments");
                // 현 URL 해시의 해당 정보를 가진 route 에서 정의된 arguments 를 포함한 키-밸류 구조의 객체 를 불러온다??
                // navTo method 를 통해

                this._updateUIElements();

                // Save the current route name
                this.currentRouteName = sRouteName;       //App의 public property(currentRouteName)세팅
                this.currentProduct = oArguments.product; //App의 public property(currentProduct)세팅 
                this.currentApvData = oArguments.apvData;
                // this.currentProduct = oEvent.getParameter().arguments.product // 와 동일?????  확인 필요
            },
    
            onStateChanged: function (oEvent) {
                //속성(layout)이 변경될때, 사용자가 layout 변경 화살표를 클릭할 때,
                //사용자가 화면Size를 변경하여 화면에 표시되는 column이 변경될 때 호출된다.
                
                var bIsNavigationArrow = oEvent.getParameter("isNavigationArrow");
                var sLayout = oEvent.getParameter("layout");
                // 변경된 layout 을 가져와 sLayout 에 넣기

                this._updateUIElements();

                // URL을 강제로 변경하여 router가 호출되도록 한다.
                // Parameter( RouterName, Paramter Object, History저장유무)
                if (bIsNavigationArrow) {
                    this.oRouter.navTo(this.currentRouteName, {layout: sLayout, product: this.currentProduct, apvData: this.currentApvData}, true);
                }
            },

            // Update the close/fullscreen buttons visibility
            _updateUIElements: function () {
                var oModel = this.oOwnerComponent.getModel(),
                    oUIState;
                this.oOwnerComponent.getHelper().then(function(oHelper) {
                    oUIState = oHelper.getCurrentUIState();
                    oModel.setData(oUIState);
                });
            },

            onExit : function() {
                //Controller에 Hook되어 있는 Exit Event(controller가 제거될대)
                this.oRouter.detachRouteMatched(this._onRouteMatched, this); //AttachRouteMatch를 풀어준다.
                this.oRouter.detachBeforeRouteMatched(this.onBeforeRouteMatched, this);
            }
            
        });
    });