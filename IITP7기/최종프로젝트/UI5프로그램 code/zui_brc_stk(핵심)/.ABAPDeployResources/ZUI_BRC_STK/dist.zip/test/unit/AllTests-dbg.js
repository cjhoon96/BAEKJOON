sap.ui.define([
	"krgoiitpgr5clb05/zui_brc_stk/test/unit/controller/App.controller"
], function () {
	"use strict";
});
