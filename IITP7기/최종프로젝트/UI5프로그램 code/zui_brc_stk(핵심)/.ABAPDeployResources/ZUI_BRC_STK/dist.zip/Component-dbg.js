sap.ui.define([
        "sap/ui/core/UIComponent",
        "sap/ui/model/json/JSONModel",
        'sap/f/library',
        "sap/f/FlexibleColumnLayoutSemanticHelper"
    ],
    function (UIComponent, JSONModel, fioriLibrary, FlexibleColumnLayoutSemanticHelper) {
        "use strict";

        return UIComponent.extend("kr.go.iitp.gr5.clb05.zuibrcstk.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                var oModel, oStockModel, oStoProcModel, oOthersModel, oRouter, userInfo, userId;

                UIComponent.prototype.init.apply(this, arguments);

                // // layout을 저장하기 위한 Model model 이름을 지정하지 않아 이름 없이 호출이 가능하다.
                oModel = new JSONModel();
                userInfo = sap.ushell.Container.getService("UserInfo");
                userId = userInfo.getId();
                console.log(userInfo, userId);
                oModel.setProperty('/userID', userId);
                console.log(oModel);
                this.setModel(oModel);
                // // Data를 가져올 Model stockData 로 이름을 지정하여 stockData> 를 접미에 붙여 사용한다.
                // oStockModel = new JSONModel();
                // oStockModel.loadData("../model/data.json");
                // this.setModel(oStockModel, 'stockData');

                // sStockModel = this.getMetadata().getManifestEntry("sap.app").dataSources["stockData"].uri;
                // var oStockModel = new sap.ui.model.odata.v2.ODataModel(sStockModel)
                // sStoProcModel = this.getMetadata().getManifestEntry("sap.app").dataSources["stoProc"].uri;
                // var oStoProcModel = new sap.ui.model.odata.v2.ODataModel(sStoProcModel)
                // this.setModel(oStockModel, "stockData");
                // this.setModel(oStoProcModel, "stoProcData");
                oStockModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZVB05_CDS_STOCKAIO_CDS/");
                oStoProcModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZGWB05_STO_PROCESS_SRV/");
                oOthersModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZVB05_CDS_STOCKAIO_ALL_CDS/");
                sap.ui.getCore().setModel(oStockModel, 'stockData');
                sap.ui.getCore().setModel(oStoProcModel, 'stoProc');
                sap.ui.getCore().setModel(oOthersModel, 'othersData');
                console.log(oModel);
                console.log(oStockModel);
                console.log(oStoProcModel);
                oRouter = this.getRouter(); 
                // Component 에 내장된 Router를 읽어들인다.
                oRouter.attachBeforeRouteMatched(this._onBeforeRouteMatched, this);
                // 어떠한 URL이든지 pattern이 일치하면 RouteMatched (event) 바로 직전에 호출된다.
                oRouter.initialize();
            },
            
            getHelper: function () {
                return this._getFcl().then(function (oFCL) {
                    var oSettings = {
                        defaultTwoColumnLayoutType: fioriLibrary.LayoutType.TwoColumnsMidExpended,
                        defaultThreeColumnLayoutType: fioriLibrary.LayoutType.ThreeColumnsEndExpended
                    };
                    return(FlexibleColumnLayoutSemanticHelper.getInstanceFor(oFCL, oSettings));
                })
            },

            _onBeforeRouteMatched: function(oEvent) {

                //URL상의 pattern이 일치하기 직전에 호출된다.
                //최초 Master의 pattern이 "pattern": ":layout:" 이므로(Option) 기본주소값이 호출되어
                //이 App의 실행과 동시에 이 부분이 호출된다. 
                var oModel = this.getModel()
                var sLayout = oEvent.getParameters().arguments.layout;
                var oNextUIState;
                // 대강은 이해 되는데 완벽하게 이해 X                                                      질문!!


                // argments 에 layout 에 지정된 것이 없는 경우
                if (!sLayout) {
                    this.getHelper().then(function (oHelper) {
                        oNextUIState = oHelper.getNextUIState(0);
                        oModel.setProperty("/layout", oNextUIState.layout);
                    });
                    return;
                    // sLayout = fioriLibrary.LayoutType.OneColumn;
                    // sLayout 을 OneColumn 으로 설정해 준다.
                }

                oModel.setProperty("/layout", sLayout);
                // 현 sLayout 을 Model 의 layout 의 값으로 설정해 준다. 
                // 따라서 최초 호출시의 layout의 값은 OneColumn 이된다.
            },

            _getFcl: function () {
                return new Promise(function (resolve, reject) {
                    var oFCL = this.getRootControl().byId("App");
                    if (!oFCL) {
                        this.getRootcontrol().attachAfterInit(function(oEvent) {
                            resolve(oEvent.getSource().byId('App'));
                        }, this);
                        return;
                    }
                    resolve(oFCL);
    
                }.bind(this));
            }
        });
    });