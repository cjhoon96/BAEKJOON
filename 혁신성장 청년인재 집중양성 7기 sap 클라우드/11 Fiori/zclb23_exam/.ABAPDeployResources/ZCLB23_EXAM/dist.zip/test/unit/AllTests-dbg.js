sap.ui.define([
	"iitp/zclb23_exam/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
