sap.ui.define([
	"IITP/zclb23_001/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
