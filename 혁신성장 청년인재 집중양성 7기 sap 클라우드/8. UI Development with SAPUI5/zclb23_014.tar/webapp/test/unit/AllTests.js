sap.ui.define([
	"zclb23_014/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
